# CLIP-demo

HCI lab03, using CLIP to build an image search framework, performing five-stage search framework.

## Usage

1. use conda to create environment: lab03
2. activate the environment: lab03
3. run the following script:  `python test.py`
4. Pre train the model on selected dataset, providing stash url and token
